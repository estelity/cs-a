package com.example;

public class Main {
    public static void main(String[] args) {
        Game2048 meow = new Game2048();
    }
}